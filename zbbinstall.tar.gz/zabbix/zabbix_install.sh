#!/bin/bash
systemctl stop httpd
systemctl disable httpd
yum -y install gcc pcre-devel openssl-devel php php-mysql mariadb mariadb-devel mariadb-server  net-snmp-devel curl-devel  php-gd php-xml 
yum -y install php-bcmath-5.4.16-42.el7.x86_64.rpm php-mbstring-5.4.16-42.el7.x86_64.rpm php-fpm-5.4.16-42.el7.x86_64.rpm libevent-devel-2.0.21-4.el7.x86_64.rpm
tar -xf nginx-1.12.2.tar.gz
cd nginx-1.12.2
./configure --with-http_ssl_module
make && make install
sed -i '45s/html/php/' /usr/local/nginx/conf/nginx.conf
sed -i '65,71s/#//' /usr/local/nginx/conf/nginx.conf
sed -i '69d' /usr/local/nginx/conf/nginx.conf
sed -i  '69s/fastcgi_params/fastcgi.conf/' /usr/local/nginx/conf/nginx.conf
sed -i '21a fastcgi_buffers 8 16k;' /usr/local/nginx/conf/nginx.conf
sed -i '22a fastcgi_buffer_size 32k;' /usr/local/nginx/conf/nginx.conf
sed -i '23a fastcgi_connect_timeout 300;' /usr/local/nginx/conf/nginx.conf
sed -i '24a fastcgi_send_timeout 300;' /usr/local/nginx/conf/nginx.conf
sed -i '25a fastcgi_read_timeout 300;' /usr/local/nginx/conf/nginx.conf
systemctl start  mariadb
systemctl start  php-fpm
ln -s /usr/local/nginx/sbin/nginx /sbin/nginx
nginx
cd ..
tar -xf zabbix-3.4.4.tar.gz
cd zabbix-3.4.4/
./configure --enable-server --enable-proxy --enable-agent --with-mysql=/usr/bin/mysql_config --with-net-snmp --with-libcurl
make && make install
systemctl restart mariadb
mysqladmin -uroot password "123456"
mysql -uroot -p123456 -e "create database zabbix character set utf8"
mysql -uroot -p123456 -e "grant all on zabbix.* to zabbix@'localhost' identified by 'zabbix'"
cd database/mysql/
mysql -uzabbix -pzabbix zabbix < schema.sql
mysql -uzabbix -pzabbix zabbix < images.sql
mysql -uzabbix -pzabbix zabbix < data.sql
cd ../../frontends/php/
cp -r * /usr/local/nginx/html/
cd
chmod -R 777 /usr/local/nginx/html/*
sed -i '85c DBHost=localhost' /usr/local/etc/zabbix_server.conf
sed -i '94c DBName=zabbix' /usr/local/etc/zabbix_server.conf
sed -i '118c DBPassword=zabbix' /usr/local/etc/zabbix_server.conf
sed -i '110c DBUser=zabbix' /usr/local/etc/zabbix_server.conf
sed -i '38c LogFile=/tmp/zabbix_server.log' /usr/local/etc/zabbix_server.conf
useradd -s /sbin/nologin zabbix
sed -i '93c Server=127.0.0.1,192.168.2.5' /usr/local/etc/zabbix_agentd.conf
sed -i '134c ServerActive=127.0.0.1,192.168.2.5' /usr/local/etc/zabbix_agentd.conf
sed -i  '145c Hostname=Zabbix_server' /usr/local/etc/zabbix_agentd.conf
sed -i '280c UnsafeUserParameters=1' /usr/local/etc/zabbix_agentd.conf
sed -i '30c LogFile=/tmp/zabbix_server.log' /usr/local/etc/zabbix_agentd.conf

sed -i '877c date.timezone = Asia/Shanghai' /etc/php.ini
sed -i '384c max_execution_time = 300' /etc/php.ini
sed -i '394c max_input_time = 300' /etc/php.ini
sed -i '405c memory_limit = 128M' /etc/php.ini
sed -i '672c post_max_size = 32M' /etc/php.ini
systemctl restart php-fpm
zabbix_server
zabbix_agentd
firefox http://localhost/index.php


